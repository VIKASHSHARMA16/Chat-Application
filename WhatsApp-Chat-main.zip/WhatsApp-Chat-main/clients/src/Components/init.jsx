window.global ||= window;
