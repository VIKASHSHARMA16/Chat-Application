export const stories = [
  {
    image:
      "https://images.pexels.com/photos/13272984/pexels-photo-13272984.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load",
  },
  {
    image:
      "https://images.pexels.com/photos/6878247/pexels-photo-6878247.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    image:
      "https://images.pexels.com/photos/15393513/pexels-photo-15393513/free-photo-of-brown-sheep-in-close-up-photography.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
];
