export const REGISTER="REGISTER";
export const LOGIN='LOGIN' 
export const REQ_USER='REQ_USER'
export const SEARCH_USER='SERCH_USER'
export const UPDATE_USER='UPDATE_USER'
export const LOGOUT='LOGOUT'