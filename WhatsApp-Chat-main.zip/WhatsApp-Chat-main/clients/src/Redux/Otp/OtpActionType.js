export const EMAIL_TYPE='EMAIL_TYPE'
export const CHECK_OTP='CHECK_OTP'