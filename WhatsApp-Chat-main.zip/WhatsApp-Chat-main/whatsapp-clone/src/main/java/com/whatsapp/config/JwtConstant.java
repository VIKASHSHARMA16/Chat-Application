package com.whatsapp.config;

public class JwtConstant {
	
        public static final String JWT_HEADER="Authorization";
        public static final String SECRET_KEY= "sdnfjsrbwqergvcdfgvrtvfgvbvcf,hbbnbvcf";
        
        
}
