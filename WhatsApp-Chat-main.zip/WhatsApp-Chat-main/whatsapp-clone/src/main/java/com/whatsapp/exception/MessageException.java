package com.whatsapp.exception;

public class MessageException extends Exception {
	
           public  MessageException(String message) {
        	       super(message);
           }
}
