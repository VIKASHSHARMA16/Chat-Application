package com.whatsapp.exception;

public class ChatException extends Exception {
        
	        public ChatException(String message) {
	        	super(message);
	        }
}
